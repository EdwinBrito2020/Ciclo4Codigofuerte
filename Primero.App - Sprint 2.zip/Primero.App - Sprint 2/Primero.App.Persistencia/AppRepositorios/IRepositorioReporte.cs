using System;
using Primero.App.Dominio;
namespace Primero.App.Persistencia
{
    public interface IRepositorioReporte
    {
        Reporte AddReporte(Reporte reporte);
        Reporte UpdateReporte(Reporte reporte);
        void DeleteReportexId(int id);
        Reporte GetReportexId(int id);

    }
}