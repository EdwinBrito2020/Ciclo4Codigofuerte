using System;
using Primero.App.Dominio;

namespace Primero.App.Persistencia
{
    public interface IRepositorioTecnico
    {
        Tecnico AddTecnico(Tecnico tecnico);
        Tecnico UpdateTecnico(Tecnico tecnico);
        //void DeleteTecnicoxId(int id);
        void DeleteTecnicoxCedula(string cedula);
        Tecnico GetTecnicoxCedula(string cedula);

    }
}