using System;
using Primero.App.Dominio;

namespace Primero.App.Persistencia
{
    public interface IRepositorioPersona
    {
        Persona AddPersona(Persona persona);
        Persona UpdatePersona(Persona persona);
        void DeletePersonaxCedula(string cedula);
        Persona GetPersonaxId(int id);

    }
}