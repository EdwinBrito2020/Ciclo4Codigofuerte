﻿using System;
using Primero.App.Dominio;
using Primero.App.Persistencia;
namespace Primero.App.Consola
{
    class Program
    {
        private static IRepositorioPersona _repo2=new RepositorioPersona(new Primero.App.Persistencia.AppContext());
        private static IRepositorioTecnico _repo=new RepositorioTecnico(new Primero.App.Persistencia.AppContext());
        static void Main(string[] args)
        {
            Console.WriteLine("Inicio Sprint Ciclo 3 Grupo 5");
            Console.WriteLine("Inicio Insertar Registro");
            Insertar();
            Console.WriteLine("Fin Insertar Registro");
            Console.WriteLine("Inicio Consultar Registro");
            Consultar();
            Console.WriteLine("Fin Consultar de Registro");
            Console.WriteLine("Inicio Borrar Registro");
            Borrar();
            Console.WriteLine("Fin Borrar Registro");
            Console.WriteLine("Fin Pruebas");
        }

        private static void Insertar()
        {
            //var p=new Persona
            var p=new Tecnico
            {
                Cedula="1202020",
                Nombre="Maria",
                Apellido="Lopez",
                Telefono="311000004",
                TarjetaProfesional="552255"
            };
            //_repo.AddPersona(p);
            _repo.AddTecnico(p);
        }

        private static void Consultar()
        {
            var r=_repo.GetTecnicoxCedula("1202020");
            Console.WriteLine("Registro consultado por Cedula: "+r.Cedula+" Nombre: "+r.Nombre+" "+r.Apellido+" Telefono: "+r.Telefono);
        }

        private static void Borrar()
        {
            _repo2.DeletePersonaxCedula("45454");
        }
    }
}
