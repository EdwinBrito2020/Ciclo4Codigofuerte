using System;

namespace Primero.App.Dominio
{
    public class Tecnico:Persona
    {
        public string TarjetaProfesional{get;set;}
    }

}