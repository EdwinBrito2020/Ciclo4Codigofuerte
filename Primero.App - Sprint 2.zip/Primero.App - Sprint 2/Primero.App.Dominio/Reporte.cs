using System;

namespace Primero.App.Dominio
{
    public class Reporte
    {
        public int Id{get;set;}
        public string Descripcion{get;set;}
        
    }
}