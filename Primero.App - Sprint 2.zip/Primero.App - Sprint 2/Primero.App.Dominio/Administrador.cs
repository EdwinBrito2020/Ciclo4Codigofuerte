using System;

namespace Primero.App.Dominio
{
    public class Administrador:Persona
    {
        public int Password{get;set;}
        public string Roll{get;set;}
    }
}