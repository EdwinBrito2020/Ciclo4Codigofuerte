﻿using System;

namespace Primero.App.Dominio
{
    public class Class1
    {
    }
}
